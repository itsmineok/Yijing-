[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string] $Manifest,

    [switch] $AllowMissingDownloadedAssets
)

$ErrorActionPreference = 'Stop'
$manifestPath = (Resolve-Path -LiteralPath $Manifest).Path
$assetRoot = [System.IO.Path]::GetFullPath((Split-Path -Parent $manifestPath))
$document = Get-Content -Raw -LiteralPath $manifestPath | ConvertFrom-Json
$verified = 0
$missing = 0
$errors = [System.Collections.Generic.List[string]]::new()
$checked = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)

function Resolve-AssetPath([string] $RelativePath) {
    if ([System.IO.Path]::IsPathRooted($RelativePath)) {
        throw "Manifest asset path must be relative: $RelativePath"
    }
    $fullPath = [System.IO.Path]::GetFullPath((Join-Path $assetRoot $RelativePath))
    $rootPrefix = $assetRoot.TrimEnd('\', '/') + [System.IO.Path]::DirectorySeparatorChar
    if (-not $fullPath.StartsWith($rootPrefix, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Manifest asset path escapes asset root: $RelativePath"
    }
    return $fullPath
}

function Get-RelativeRuntimePath([string] $Root, [string] $Path) {
    $rootPrefix = [System.IO.Path]::GetFullPath($Root).TrimEnd('\', '/') + [System.IO.Path]::DirectorySeparatorChar
    $fullPath = [System.IO.Path]::GetFullPath($Path)
    if (-not $fullPath.StartsWith($rootPrefix, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Runtime file escaped destination root: $fullPath"
    }
    return $fullPath.Substring($rootPrefix.Length).Replace('\', '/')
}

function Test-IsDownloadedAsset([string] $RelativePath) {
    $normalized = $RelativePath.Replace('\', '/')
    foreach ($download in $document.downloads) {
        $destination = ([string] $download.destination).Replace('\', '/').TrimEnd('/')
        if ([string] $download.kind -ceq 'File' -and
            $normalized.Equals($destination, [System.StringComparison]::OrdinalIgnoreCase)) {
            return $true
        }
        if ([string] $download.kind -ceq 'Archive' -and
            $normalized.StartsWith($destination + '/', [System.StringComparison]::OrdinalIgnoreCase)) {
            return $true
        }
    }
    return $false
}

function Test-Digest([string] $Path, [string] $Expected, [string] $Description) {
    if ($Expected -notmatch '^[0-9a-fA-F]{64}$') {
        $errors.Add("Missing or invalid SHA-256 for $Description")
        return
    }
    $actual = (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -cne $Expected.ToLowerInvariant()) {
        $errors.Add("SHA-256 mismatch for $Description expected=$($Expected.ToLowerInvariant()) actual=$actual")
        return
    }
    Write-Output "VERIFIED $Description"
    $script:verified++
}

foreach ($download in $document.downloads) {
    try {
        $destination = Resolve-AssetPath ([string] $download.destination)
        if ([string] $download.kind -ceq 'Archive') {
            if (-not (Test-Path -LiteralPath $destination -PathType Container)) {
                if ($AllowMissingDownloadedAssets) {
                    Write-Output "MISSING download-only runtime: $($download.destination)"
                    $missing++
                }
                else {
                    $errors.Add("Missing runtime directory: $($download.destination)")
                }
                continue
            }

            $expected = [System.Collections.Generic.Dictionary[string,string]]::new(
                [System.StringComparer]::OrdinalIgnoreCase)
            foreach ($runtimeFile in $download.runtimeFiles) {
                $expected.Add(([string] $runtimeFile.path).Replace('\', '/'), [string] $runtimeFile.sha256)
            }
            if ($expected.Count -eq 0) {
                $errors.Add("Archive has no committed runtime allow-list: $($download.name)")
                continue
            }

            $actualFiles = Get-ChildItem -LiteralPath $destination -Recurse -File
            foreach ($file in $actualFiles) {
                $relative = Get-RelativeRuntimePath $destination $file.FullName
                if (-not $expected.ContainsKey($relative)) {
                    $errors.Add("Runtime file is not in the committed allow-list: $($download.destination)/$relative")
                    continue
                }
                Test-Digest $file.FullName $expected[$relative] "$($download.destination)/$relative"
                [void] $expected.Remove($relative)
                [void] $checked.Add($file.FullName)
            }
            foreach ($relative in $expected.Keys) {
                $errors.Add("Missing committed runtime file: $($download.destination)/$relative")
            }
        }
        elseif ([string] $download.kind -ceq 'File') {
            if (-not (Test-Path -LiteralPath $destination -PathType Leaf)) {
                if ($AllowMissingDownloadedAssets) {
                    Write-Output "MISSING download-only asset: $($download.destination)"
                    $missing++
                }
                else {
                    $errors.Add("Missing asset: $($download.destination)")
                }
                continue
            }
            Test-Digest $destination ([string] $download.expectedArchiveSha256) ([string] $download.destination)
            [void] $checked.Add($destination)
        }
        else {
            $errors.Add("Unsupported download kind '$($download.kind)': $($download.name)")
        }
    }
    catch {
        $errors.Add($_.Exception.Message)
    }
}

foreach ($candidate in $document.candidates) {
    $assets = @(
        @{ Path = [string] $candidate.executable; Digest = [string] $candidate.sha256.executable },
        @{ Path = [string] $candidate.model; Digest = [string] $candidate.sha256.model },
        @{ Path = [string] $candidate.config; Digest = [string] $candidate.sha256.config }
    )
    foreach ($asset in $assets) {
        try {
            $path = Resolve-AssetPath $asset.Path
            if ($checked.Contains($path)) { continue }
            if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
                $isDownloadOnly = Test-IsDownloadedAsset $asset.Path
                if ($AllowMissingDownloadedAssets -and $isDownloadOnly) {
                    continue
                }
                $errors.Add("Missing candidate asset: $($asset.Path)")
                continue
            }
            Test-Digest $path $asset.Digest $asset.Path
            [void] $checked.Add($path)
        }
        catch {
            $errors.Add($_.Exception.Message)
        }
    }
}

foreach ($errorMessage in $errors) {
    Write-Error $errorMessage -ErrorAction Continue
}
Write-Output "KataGo asset verification summary: verified=$verified missing-download-only=$missing errors=$($errors.Count)"
if ($errors.Count -gt 0) {
    throw "KataGo asset verification failed with $($errors.Count) error(s)."
}
