[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string] $Manifest = (Join-Path $PSScriptRoot '..\assets\katago\engine-manifest.json'),

    [Parameter(Mandatory = $false)]
    [string] $DownloadDirectory,

    [switch] $UseExistingDownloads,

    [switch] $KeepDownloads
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$manifestPath = [System.IO.Path]::GetFullPath($Manifest)
$assetRoot = [System.IO.Path]::GetFullPath((Split-Path -Parent $manifestPath))
$document = Get-Content -Raw -LiteralPath $manifestPath | ConvertFrom-Json
$downloadRootWasAutoCreated = [string]::IsNullOrWhiteSpace($DownloadDirectory)
if ($downloadRootWasAutoCreated) {
    $DownloadDirectory = Join-Path ([System.IO.Path]::GetTempPath()) ('Yijing-KataGo-' + [guid]::NewGuid().ToString('N'))
}
$downloadRoot = [System.IO.Path]::GetFullPath($DownloadDirectory)
[System.IO.Directory]::CreateDirectory($downloadRoot) | Out-Null
$createdDownloadFiles = [System.Collections.Generic.List[string]]::new()

function Assert-OfficialSource([uri] $Uri) {
    if ($Uri.Scheme -cne 'https' -or $Uri.DnsSafeHost -cne 'github.com') {
        throw "KataGo assets must use official GitHub HTTPS release URLs: $Uri"
    }
    if (-not $Uri.AbsolutePath.StartsWith('/lightvector/KataGo/releases/download/', [System.StringComparison]::Ordinal)) {
        throw "GitHub download is not an official lightvector/KataGo release asset: $Uri"
    }
}

function Resolve-UnderAssetRoot([string] $RelativePath) {
    if ([System.IO.Path]::IsPathRooted($RelativePath)) {
        throw "Download destination must be relative: $RelativePath"
    }
    $fullPath = [System.IO.Path]::GetFullPath((Join-Path $assetRoot $RelativePath))
    $rootPrefix = $assetRoot.TrimEnd('\', '/') + [System.IO.Path]::DirectorySeparatorChar
    if (-not $fullPath.StartsWith($rootPrefix, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Download destination escapes the asset root: $RelativePath"
    }
    return $fullPath
}

function Assert-Sha256([string] $Path, [string] $Expected, [string] $Description) {
    if ($Expected -notmatch '^[0-9a-fA-F]{64}$') {
        throw "Missing or invalid committed SHA-256 for $Description"
    }
    $actual = (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -cne $Expected.ToLowerInvariant()) {
        throw "$Description SHA-256 mismatch: expected=$($Expected.ToLowerInvariant()) actual=$actual"
    }
}

function Remove-DirectoryChecked([string] $Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return }
    $fullPath = [System.IO.Path]::GetFullPath($Path)
    $rootPrefix = $assetRoot.TrimEnd('\', '/') + [System.IO.Path]::DirectorySeparatorChar
    if (-not $fullPath.StartsWith($rootPrefix, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Refusing to delete directory outside the asset root: $fullPath"
    }
    [System.IO.Directory]::Delete($fullPath, $true)
}

function Get-RelativeRuntimePath([string] $Root, [string] $Path) {
    $rootPrefix = [System.IO.Path]::GetFullPath($Root).TrimEnd('\', '/') + [System.IO.Path]::DirectorySeparatorChar
    $fullPath = [System.IO.Path]::GetFullPath($Path)
    if (-not $fullPath.StartsWith($rootPrefix, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Runtime file escaped extraction root: $fullPath"
    }
    return $fullPath.Substring($rootPrefix.Length).Replace('\', '/')
}

try {
    foreach ($download in $document.downloads) {
        $uri = [uri] $download.url
        Assert-OfficialSource $uri
        $downloadPath = Join-Path $downloadRoot ([string] $download.name)
        if (-not $UseExistingDownloads) {
            $partialPath = $downloadPath + '.partial-' + [guid]::NewGuid().ToString('N')
            try {
                Write-Output "Downloading official KataGo asset $($download.name)"
                Invoke-WebRequest -UseBasicParsing -Uri $uri -OutFile $partialPath
                [System.IO.File]::Delete($downloadPath)
                [System.IO.File]::Move($partialPath, $downloadPath)
                $createdDownloadFiles.Add($downloadPath)
            }
            finally {
                [System.IO.File]::Delete($partialPath)
            }
        }
        elseif (-not (Test-Path -LiteralPath $downloadPath -PathType Leaf)) {
            throw "Existing download was not found: $downloadPath"
        }

        Assert-Sha256 $downloadPath ([string] $download.expectedArchiveSha256) "archive $($download.name)"
        $destination = Resolve-UnderAssetRoot ([string] $download.destination)

        if ([string] $download.kind -ceq 'Archive') {
            $newDirectory = $destination + '.new-' + [guid]::NewGuid().ToString('N')
            $oldDirectory = $destination + '.old-' + [guid]::NewGuid().ToString('N')
            $replacementSucceeded = $false
            try {
                [System.IO.Directory]::CreateDirectory($newDirectory) | Out-Null
                Expand-Archive -LiteralPath $downloadPath -DestinationPath $newDirectory

                $expectedFiles = [System.Collections.Generic.Dictionary[string,string]]::new(
                    [System.StringComparer]::OrdinalIgnoreCase)
                foreach ($runtimeFile in $download.runtimeFiles) {
                    $relative = ([string] $runtimeFile.path).Replace('\', '/')
                    if ([System.IO.Path]::IsPathRooted($relative) -or $relative.Contains('../')) {
                        throw "Invalid runtime allow-list path: $relative"
                    }
                    $expectedFiles.Add($relative, [string] $runtimeFile.sha256)
                }
                if ($expectedFiles.Count -eq 0) {
                    throw "Archive has no committed runtime allow-list: $($download.name)"
                }

                $actualFiles = Get-ChildItem -LiteralPath $newDirectory -Recurse -File
                if ($actualFiles.Count -ne $expectedFiles.Count) {
                    throw "Runtime allow-list count mismatch for $($download.name): expected=$($expectedFiles.Count) actual=$($actualFiles.Count)"
                }
                foreach ($file in $actualFiles) {
                    $relative = Get-RelativeRuntimePath $newDirectory $file.FullName
                    if (-not $expectedFiles.ContainsKey($relative)) {
                        throw "Runtime file is not in the committed allow-list: $relative"
                    }
                    Assert-Sha256 $file.FullName $expectedFiles[$relative] "runtime file $relative"
                }

                $hadOldDirectory = Test-Path -LiteralPath $destination
                if ($hadOldDirectory) {
                    [System.IO.Directory]::Move($destination, $oldDirectory)
                }
                [System.IO.Directory]::Move($newDirectory, $destination)
                $replacementSucceeded = $true
                Remove-DirectoryChecked $oldDirectory
            }
            finally {
                Remove-DirectoryChecked $newDirectory
                if ($replacementSucceeded) {
                    Remove-DirectoryChecked $oldDirectory
                }
                elseif ((Test-Path -LiteralPath $oldDirectory) -and
                        -not (Test-Path -LiteralPath $destination)) {
                    [System.IO.Directory]::Move($oldDirectory, $destination)
                }
            }
        }
        elseif ([string] $download.kind -ceq 'File') {
            [System.IO.Directory]::CreateDirectory((Split-Path -Parent $destination)) | Out-Null
            $temporaryFile = $destination + '.new-' + [guid]::NewGuid().ToString('N')
            try {
                [System.IO.File]::Copy($downloadPath, $temporaryFile, $true)
                Assert-Sha256 $temporaryFile ([string] $download.expectedArchiveSha256) "runtime file $($download.destination)"
                if (Test-Path -LiteralPath $destination -PathType Leaf) {
                    [System.IO.File]::Replace($temporaryFile, $destination, $null)
                }
                else {
                    [System.IO.File]::Move($temporaryFile, $destination)
                }
            }
            finally {
                [System.IO.File]::Delete($temporaryFile)
            }
        }
        else {
            throw "Unsupported download kind '$($download.kind)' for $($download.name)"
        }
        Write-Output "INSTALLED $($download.destination)"
    }
}
finally {
    if (-not $KeepDownloads -and $downloadRootWasAutoCreated -and (Test-Path -LiteralPath $downloadRoot)) {
        [System.IO.Directory]::Delete($downloadRoot, $true)
    }
    elseif (-not $KeepDownloads -and -not $downloadRootWasAutoCreated) {
        foreach ($createdDownloadFile in $createdDownloadFiles) {
            [System.IO.File]::Delete($createdDownloadFile)
        }
    }
}

Write-Output "KataGo assets installed from committed hashes; manifest was not modified."
