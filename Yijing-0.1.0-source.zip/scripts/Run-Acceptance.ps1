[CmdletBinding()]
param(
    [string] $Configuration = 'Release',
    [string] $Runtime = 'win-x64',
    [switch] $SkipPublish
)

$ErrorActionPreference = 'Stop'
$repo = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$artifacts = Join-Path $repo 'artifacts'
$publish = Join-Path $artifacts "publish\$Runtime"
$resultsPath = Join-Path $artifacts 'acceptance\results.json'
[System.IO.Directory]::CreateDirectory((Split-Path -Parent $resultsPath)) | Out-Null
$results = [ordered]@{
    testsPass = $false
    resourceDigestsValid = $false
    fakeEngineProtocolValid = $false
    sgfRoundTripBoardKeyMatches = $false
    undoReturnsHumanTurn = $false
    resignationResultValid = $false
    corruptModelFallsBackToEigen = $false
    autosaveRecoveryValid = $false
    publishOutputClean = $false
}

function Invoke-Checked([string] $File, [string[]] $Arguments) {
    & $File @Arguments
    if ($LASTEXITCODE -ne 0) { throw "$File exited with code $LASTEXITCODE" }
}

function Test-DotNetFilter([string] $Filter) {
    try {
        $output = & dotnet test (Join-Path $repo 'Yijing.sln') -c $Configuration `
            --no-restore --filter $Filter --nologo 2>&1
        $output | Write-Host
        if ($LASTEXITCODE -ne 0) { throw "Filtered test run exited with code $LASTEXITCODE" }
        return $true
    }
    catch { Write-Warning $_; return $false }
}

Push-Location $repo
try {
    try {
        Invoke-Checked dotnet @('test', 'Yijing.sln', '-c', $Configuration, '--nologo')
        $results.testsPass = $true
    } catch { Write-Warning $_ }

    try {
        Invoke-Checked powershell @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File',
            (Join-Path $repo 'scripts\Verify-KataGoAssets.ps1'), '-Manifest',
            (Join-Path $repo 'assets\katago\engine-manifest.json'))
        $results.resourceDigestsValid = $true
    } catch { Write-Warning $_ }

    try {
        $fakeOut = Join-Path $artifacts "fake-katago\$Runtime"
        Invoke-Checked dotnet @('publish', 'tools\FakeKataGo\FakeKataGo.csproj', '-c', $Configuration,
            '-r', $Runtime, '--self-contained', 'true', '-o', $fakeOut, '--nologo')
        $requestFile = Join-Path $artifacts 'acceptance\fake-input.jsonl'
        $outputFile = Join-Path $artifacts 'acceptance\fake-output.jsonl'
        $errorFile = Join-Path $artifacts 'acceptance\fake-error.log'
        $requestLines = @(
            '{"id":"acceptance","moves":[],"initialPlayer":"B","rules":"chinese","komi":7.5,"boardXSize":19,"boardYSize":19}',
            '{"id":"stop-acceptance","action":"terminate","terminateId":"acceptance"}'
        )
        [System.IO.File]::WriteAllLines($requestFile, $requestLines, [System.Text.UTF8Encoding]::new($false))
        $process = Start-Process -FilePath (Join-Path $fakeOut 'FakeKataGo.exe') -NoNewWindow -Wait -PassThru `
            -RedirectStandardInput $requestFile -RedirectStandardOutput $outputFile -RedirectStandardError $errorFile
        if ($process.ExitCode -ne 0) { throw "Fake engine exited with code $($process.ExitCode)" }
        $responses = @(Get-Content -LiteralPath $outputFile | ForEach-Object { $_ | ConvertFrom-Json })
        $results.fakeEngineProtocolValid =
            ($responses.Count -eq 3) -and
            ($responses[0].isDuringSearch -eq $true) -and ($responses[0].moveInfos[0].move -eq 'D4') -and
            ($responses[1].isDuringSearch -eq $false) -and ($responses[1].moveInfos[0].move -eq 'Q16') -and
            ($responses[2].action -eq 'terminate') -and ($responses[2].terminateId -eq 'acceptance')
    } catch { Write-Warning $_ }

    $results.sgfRoundTripBoardKeyMatches = Test-DotNetFilter 'FullyQualifiedName~ReleaseAcceptanceTests.ScriptedNineByNineGameRoundTripsWithSameFinalBoardKey'
    $results.undoReturnsHumanTurn = Test-DotNetFilter 'FullyQualifiedName~Undo_AfterAiReplyReturnsToBeforeHumansLastMove|FullyQualifiedName~Human_white_cannot_undo_after_the_ai_has_played_its_opening'
    $results.resignationResultValid = Test-DotNetFilter 'FullyQualifiedName~Resign_StoresSgfResultForOpponent|FullyQualifiedName~Resign_confirmation_stores_white_resignation_win_when_human_is_black'
    $results.corruptModelFallsBackToEigen = Test-DotNetFilter 'FullyQualifiedName~Sha256MismatchRejectsCandidateBeforeProcessLaunch|FullyQualifiedName~UnsupportedAvx2SkipsAvx2AndProbesGenericEigen'
    $results.autosaveRecoveryValid = Test-DotNetFilter 'FullyQualifiedName~Autosave_restore_replays_all_moves_through_rules_and_rejects_tampered_history|FullyQualifiedName~Startup_autosave_asks_the_exact_restore_question_before_replaying'

    try {
        if (-not $SkipPublish) {
            if (Test-Path -LiteralPath $publish) { Remove-Item -LiteralPath $publish -Recurse -Force }
            Invoke-Checked dotnet @('publish', 'src\Yijing.Desktop\Yijing.Desktop.csproj', '-c', $Configuration,
                '-r', $Runtime, '--self-contained', 'true', '-o', $publish, '--nologo')
        }
        $required = Join-Path $publish 'Yijing.Desktop.exe'
        $forbidden = @(Get-ChildItem -LiteralPath $publish -Recurse -File | Where-Object {
            $_.Extension -in @('.pdb', '.user', '.log', '.sgf') -or
            $_.Name -match '^(autosave|settings|engine-profile)\.' -or
            $_.FullName -match '[\\/]\.downloads[\\/]'
        })
        $results.publishOutputClean = (Test-Path -LiteralPath $required -PathType Leaf) -and $forbidden.Count -eq 0
    } catch { Write-Warning $_ }
}
finally {
    Pop-Location
    [System.IO.File]::WriteAllText(
        $resultsPath,
        ($results | ConvertTo-Json),
        [System.Text.UTF8Encoding]::new($false))
}

$results | Format-Table -AutoSize
if ($results.Values -contains $false) {
    Write-Error "Acceptance failed. See $resultsPath"
    exit 1
}
Write-Output "All nine acceptance checks passed: $resultsPath"
